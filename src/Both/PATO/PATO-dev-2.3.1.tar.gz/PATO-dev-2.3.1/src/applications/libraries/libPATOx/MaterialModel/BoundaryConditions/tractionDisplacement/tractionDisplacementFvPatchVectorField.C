/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2016 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "tractionDisplacementFvPatchVectorField.H"
#include "addToRunTimeSelectionTable.H"
#include "volFields.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

tractionDisplacementFvPatchVectorField::
tractionDisplacementFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF
)
  :
fixedGradientFvPatchVectorField(p, iF),
traction_(p.size(), Zero),
pressure_(p.size(), 0.0)
{
  fvPatchVectorField::operator=(patchInternalField());
  gradient() = Zero;
}


tractionDisplacementFvPatchVectorField::
tractionDisplacementFvPatchVectorField
(
    const tractionDisplacementFvPatchVectorField& tdpvf,
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
  :
fixedGradientFvPatchVectorField(tdpvf, p, iF, mapper),
traction_(mapper(tdpvf.traction_)),
pressure_(mapper(tdpvf.pressure_))
{}


tractionDisplacementFvPatchVectorField::
tractionDisplacementFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const dictionary& dict
)
  :
fixedGradientFvPatchVectorField(p, iF),
traction_("traction", dict, p.size()),
pressure_("pressure", dict, p.size())
{
  fvPatchVectorField::operator=(patchInternalField());
  gradient() = Zero;
}


tractionDisplacementFvPatchVectorField::
tractionDisplacementFvPatchVectorField
(
    const tractionDisplacementFvPatchVectorField& tdpvf
)
  :
fixedGradientFvPatchVectorField(tdpvf),
traction_(tdpvf.traction_),
pressure_(tdpvf.pressure_)
{}


tractionDisplacementFvPatchVectorField::
tractionDisplacementFvPatchVectorField
(
    const tractionDisplacementFvPatchVectorField& tdpvf,
    const DimensionedField<vector, volMesh>& iF
)
  :
fixedGradientFvPatchVectorField(tdpvf, iF),
traction_(tdpvf.traction_),
pressure_(tdpvf.pressure_)
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void tractionDisplacementFvPatchVectorField::autoMap
(
    const fvPatchFieldMapper& m
)
{
  fixedGradientFvPatchVectorField::autoMap(m);
  m(traction_, traction_);
  m(pressure_, pressure_);
}


void tractionDisplacementFvPatchVectorField::rmap
(
    const fvPatchVectorField& ptf,
    const labelList& addr
)
{
  fixedGradientFvPatchVectorField::rmap(ptf, addr);

  const tractionDisplacementFvPatchVectorField& dmptf =
      refCast<const tractionDisplacementFvPatchVectorField>(ptf);

  traction_.rmap(dmptf.traction_, addr);
  pressure_.rmap(dmptf.pressure_, addr);
}


void tractionDisplacementFvPatchVectorField::updateCoeffs()
{
  if (updated()) {
    return;
  }

  /*    const dictionary& mechanicalProperties =
          db().lookupObject<IOdictionary>("mechanicalProperties");

      const dictionary& thermalProperties =
          db().lookupObject<IOdictionary>("thermalProperties");

      const dictionary& pyrolysisProperties =
          db().lookupObject<IOdictionary>("pyrolysisProperties");
  */

  const fvPatchField<scalar>& rho =
      patch().lookupPatchField<volScalarField, scalar>("rho");

//    const fvPatchField<scalar>& rhoE =
//        patch().lookupPatchField<volScalarField, scalar>("E");

  const fvPatchField<scalar>& E =
      patch().lookupPatchField<volScalarField, scalar>("E"); // test version in PATOx, E is already equal to E/rho

  const fvPatchField<scalar>& nu =
      patch().lookupPatchField<volScalarField, scalar>("nu");

//    scalarField E(rhoE/rho);
  scalarField mu(E/(2.0*(1.0 + nu)));
  scalarField lambda(nu*E/((1.0 + nu)*(1.0 - 2.0*nu)));
  scalarField threeK(E/(1.0 - 2.0*nu));

//    Switch planeStress(mechanicalProperties.lookup("planeStress"));

//    if (planeStress)
  {
    lambda = nu*E/((1.0 + nu)*(1.0 - nu));
    threeK = E/(1.0 - nu);
  }

  scalarField twoMuLambda(2*mu + lambda);

  vectorField n(patch().nf());

  const fvPatchField<symmTensor>& sigmaD =
      patch().lookupPatchField<volSymmTensorField, symmTensor>("sigmaD");

  gradient() =
      (
          (traction_ - pressure_*n)/rho
          + twoMuLambda*fvPatchField<vector>::snGrad() - (n & sigmaD)
      )/twoMuLambda;

//    Switch thermalStress(thermalProperties.lookup("thermalStress"));

//    if (thermalStress)
  {
    const fvPatchField<scalar>&  threeKalpha=
        patch().lookupPatchField<volScalarField, scalar>("threeKalpha");

    const fvPatchField<scalar>& T =
        patch().lookupPatchField<volScalarField, scalar>("Ta");

    gradient() += n*threeKalpha*T/twoMuLambda;
  }

//    Switch pyrolysisStress(pyrolysisProperties.lookup("pyrolysisStress"));

//    if (pyrolysisStress)
  {
    //const fvPatchField<scalar>&  threeKalpha=
    //patch().lookupPatchField<volScalarField, scalar>("threeKalpha");

    const fvPatchField<scalar>& tau =
        patch().lookupPatchField<volScalarField, scalar>("tau");

    gradient() -= n*threeK*(1-tau)/6/twoMuLambda;
  }

  fixedGradientFvPatchVectorField::updateCoeffs();
}


void tractionDisplacementFvPatchVectorField::write(Ostream& os) const
{
  fvPatchVectorField::write(os);
  writeEntry(os, "traction", traction_);
  writeEntry(os, "pressure", pressure_);
  writeEntry(os, "value", *this);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

makePatchTypeField
(
    fvPatchVectorField,
    tractionDisplacementFvPatchVectorField
);

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
